<?php

require_once 'gumstix/tests/erp/ErpTestCase.php';

/**
 * @author Ian Phillips <ian@gumstix.com>
 */
class ${name}
extends ErpTestCase
{
    public function test()
    {

    }
}