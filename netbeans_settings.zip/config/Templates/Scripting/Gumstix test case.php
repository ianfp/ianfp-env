<?php

require_once 'gumstix/tests/GumstixTestCase.php';

/**
 * @author Ian Phillips <ian@gumstix.com>
 */
class ${name}
extends GumstixTestCase
{
    

    public function setUp()
    {

    }

    public function test()
    {

    }
}