<?php

require_once 'gumstix/erp/exceptions/Weberp.php';

/**
 * @author Ian Phillips <ian@gumstix.com>
 */
class ${name}
extends WeberpException
{
    /* no modifications */
}
