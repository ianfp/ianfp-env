<?php

use Rialto\_Bundle\Entity\;

require_once 'gumstix/erp/mappers/ErpDbTableMapper.php';


/**
 * @author Ian Phillips <ian@gumstix.com>
 */
class ${name}
extends ErpDbTableMapper
{
    public function getTableName()
    {
        return '';
    }

    protected function instantiate(array $data)
    {
        return new ();
    }
}
