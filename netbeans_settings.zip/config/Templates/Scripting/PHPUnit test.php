<?php

/**
 * @author Ian Phillips <ian@gumstix.com>
 */
class ${name}
extends PHPUnit_Framework_TestCase
{
    public function test()
    {

    }
}
