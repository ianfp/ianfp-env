<?php

namespace Rialto\_Bundle\;

/**
 *
 */
class ${name}
{

}
