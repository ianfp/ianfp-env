<?php

require_once 'gumstix/tests/erp/erp_test_config.php';
require_once 'gumstix/tests/erp/ErpDatabaseTestCase.php';

/**
 * @author Ian Phillips <ian@gumstix.com>
 */
class ${name}
extends ErpDatabaseTestCase
{
}