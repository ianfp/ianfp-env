<?php

namespace Rialto\_Bundle\;

/**
 *
 */
interface ${name}
{

}
