<?php

$PageSecurity = _replaceme_;

require_once 'includes/session.inc';
require_once 'gumstix/erp/controllers/html/_replaceme_/${name}Page.php';

$page = new ${name}Page();
echo $page->render();