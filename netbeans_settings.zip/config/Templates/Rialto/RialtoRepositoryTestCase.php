<?php

namespace Rialto\_Bundle\Tests\Repository;

use Rialto\CoreBundle\Tests\RialtoRepositoryTestCase;

class ${name}
extends RialtoRepositoryTestCase
{
    public function test()
    {

    }
}