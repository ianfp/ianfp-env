<?php

namespace Rialto\_Bundle\Tests\Controller;

use Rialto\CoreBundle\Tests\RialtoWebTestCase;

/**
 * @group functional
 */
class ${name}
extends RialtoWebTestCase
{
    public function test()
    {

    }
}