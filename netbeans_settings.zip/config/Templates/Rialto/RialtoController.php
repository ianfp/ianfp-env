<?php

namespace Rialto\_Bundle\Controller;

use Rialto\CoreBundle\Controller\RialtoController;

/**
 * 
 */
class ${name}
extends RialtoController
{

}
