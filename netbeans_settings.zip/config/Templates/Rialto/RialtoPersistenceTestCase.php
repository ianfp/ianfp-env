<?php

namespace Rialto\_Bundle\Tests\Entity;

use Rialto\CoreBundle\Tests\RialtoRepositoryTestCase;

class ${name}
extends RialtoRepositoryTestCase
{
    public function test()
    {

    }
}