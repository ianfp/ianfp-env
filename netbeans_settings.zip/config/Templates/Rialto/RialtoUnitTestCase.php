<?php

namespace Rialto\_Bundle\Tests\;

use Rialto\CoreBundle\Tests\RialtoUnitTestCase;

class ${name}
extends RialtoUnitTestCase
{
    public function test()
    {

    }
}