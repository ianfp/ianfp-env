<?php

namespace Rialto\_Bundle\Form\Type;

use Rialto\CoreBundle\Form\Type\DynamicFormType;
use Symfony\Component\Form\FormBuilder;
use Symfony\Component\Form\FormInterface;
use Rialto\CoreBundle\Form\EventListener\DynamicFormSubscriber;

/**
 *
 */
class Type
extends DynamicFormType
{
    protected function getSubscriber()
    {

    }

    public function getDefaultOptions(array $options)
    {
        return array(
            'data_class' => '',
        );
    }

    public function getName()
    {
        return '';
    }
}


class Subscriber
extends DynamicFormSubscriber
{
    
}